﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace Save_the_human_rev1
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        Random random = new Random();
        DispatcherTimer EnemyTimer = new DispatcherTimer();
        DispatcherTimer TargetTimer = new DispatcherTimer();
        bool HumanCaptured = false;
        private int navigationHelper_LoadState;
        private int navigationHelper_SaveState;

        internal NavigationHelper navigationHelper { get; private set; }

        public MainPage()
        {
            this.InitializeComponent();
            this.navigationHelper = new NavigationHelper(this);
            this.navigationHelper.LoadState += navigationHelper_LoadState;
            this.navigationHelper.SaveState += navigationHelper_SaveState;

            EnemyTimer.Tick += EnemyTimer_Tick;
            EnemyTimer.Interval  = TimeSpan.FromSeconds(2);

            TargetTimer.Tick += TargetTimer_Tick;
            TargetTimer.Interval = TimeSpan.FromSeconds(.1);


        }

        void TargetTimer_Tick(object? sender, EventArgs e)
        {
            progressBar.Value += 1;
            if (progressBar.Value >= progressBar.Maximum)
                EndTheGame();
        }

        void EndTheGame()
        {
            if (!PlayArea.Children.Contains(GameOverText))
            {
                EnemyTimer.Stop();
                TargetTimer.Stop();
                HumanCaptured = false;
                StartButton.Visibility = Visibility.Visible;
                PlayArea.Children.Add(GameOverText);
                
                
            }
        }

        private void EnemyTimer_Tick(object? sender, EventArgs e)
        {
            AddEnemy();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            startGame();
        }

        private void AddEnemy()
        {
            ContentControl enemy = new ContentControl();
            enemy.Template = Resources["EnemyTemplate"] as ControlTemplate;
            AnimateEnemy(enemy, 0, PlayArea.ActualWidth - 100, "(Canvas.Left)");
            AnimateEnemy(enemy, random.Next((int)PlayArea.ActualHeight - 100),
            random.Next((int)PlayArea.ActualHeight - 100),"(Canvas.Top)");
            PlayArea.Children.Add(enemy);

            enemy.MouseEnter += Enemy_MouseEnter;
        }

        private void Enemy_MouseEnter(object sender, MouseEventArgs e)
        {
            if(HumanCaptured)
                EndTheGame();
        }

        private void startGame()
        {
            Human.IsHitTestVisible = true;
            HumanCaptured = false;
            progressBar.Value = 0;
            StartButton.Visibility = Visibility.Collapsed;
            PlayArea.Children.Clear();
            PlayArea.Children.Add(Target);
            PlayArea.Children.Add(Human);
            EnemyTimer.Start();
            TargetTimer.Start();
            
        }

        private void AnimateEnemy(ContentControl enemy, double from, double to, string PropertyToAnimate)
        {
            Storyboard storyboard = new Storyboard()
            { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever};
            DoubleAnimation animation = new DoubleAnimation()
            {
                From = from,
                To = to,
                Duration = new Duration(TimeSpan.FromSeconds(random.Next(4, 6)))
            };

            Storyboard.SetTarget(animation, enemy);
            Storyboard.SetTargetProperty(animation, new PropertyPath(PropertyToAnimate));
            storyboard.Children.Add(animation);
            storyboard.Begin();

        }

        private void Human_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (EnemyTimer.IsEnabled)
            {
                HumanCaptured = true;
                Human.IsHitTestVisible = false;
            }
        }

        private void Target_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (TargetTimer.IsEnabled && HumanCaptured)
            {
                progressBar.Value = 0;
                Canvas.SetLeft(Target, random.Next(100, (int)PlayArea.ActualWidth - 100));
                Canvas.SetTop(Target, random.Next(100, (int)PlayArea.ActualHeight - 100));
                Canvas.SetLeft(Human, random.Next(100, (int)PlayArea.ActualWidth - 100));
                Canvas.SetTop(Human, random.Next(100, (int)PlayArea.ActualWidth - 100));
                HumanCaptured = false; 
                Human.IsHitTestVisible = true;
            
            }

        }

        private void PlayArea_MouseMove(object sender, MouseEventArgs e)
        {
            if (HumanCaptured)
            {
                Point pointerPosition = e.GetPosition(null);
                Point relativePosition = grid.TransformToVisual(PlayArea).Transform(pointerPosition);
                if ((Math.Abs(relativePosition.X - Canvas.GetLeft(Human))>Human.ActualWidth*3)
                    || (Math.Abs(relativePosition.Y - Canvas.GetTop(Human)) > Human.ActualHeight * 3))
                {
                    HumanCaptured = false;
                    Human.IsHitTestVisible=true;
                }
                else
                {
                    Canvas.SetLeft(Human, relativePosition.X - Human.ActualWidth / 2);
                    Canvas.SetTop(Human, relativePosition.Y - Human.ActualHeight / 2);
                }

            }
        }

        private void PlayArea_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (HumanCaptured)
                EndTheGame();
        }
    }



    internal class NavigationHelper
    {
        private MainPage mainPage;

        public NavigationHelper(MainPage mainPage)
        {
            this.mainPage = mainPage;
        }

        public int LoadState { get; internal set; }
        public int SaveState { get; internal set; }
    }
}
